var searchData=
[
  ['destruir',['destruir',['../classImagen.html#aea77aed960516bf385f94249f074dd9a',1,'Imagen::destruir()'],['../classLista.html#a7b1f5c4b50044823f2746853bfaa5e15',1,'Lista::destruir()']]]
];
