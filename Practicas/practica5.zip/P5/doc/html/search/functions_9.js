var searchData=
[
  ['plano',['plano',['../classImagen.html#a738d3b88a80606af9d78458e5586e04c',1,'Imagen']]]
];
