var searchData=
[
  ['leerimagen',['leerImagen',['../classImagen.html#aa46cc99da218afa01f55395e4c96ffe0',1,'Imagen']]],
  ['leerlista',['leerLista',['../classLista.html#aa4be655d8d5ea8e8189e7c577c86b34e',1,'Lista']]],
  ['leerpgmbinario',['leerPGMBinario',['../pgm_8h.html#a3d11aef73fef65e3ba31446f8fc20595',1,'leerPGMBinario(const char nombre[], unsigned char datos[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp'],['../pgm_8cpp.html#a3d11aef73fef65e3ba31446f8fc20595',1,'leerPGMBinario(const char nombre[], unsigned char datos[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp']]],
  ['leerpgmtexto',['leerPGMTexto',['../pgm_8h.html#ad0376e7bb607f570d680118ef291ee3d',1,'leerPGMTexto(const char nombre[], unsigned char datos[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp'],['../pgm_8cpp.html#ad0376e7bb607f570d680118ef291ee3d',1,'leerPGMTexto(const char nombre[], unsigned char datos[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp']]],
  ['lista',['Lista',['../classLista.html',1,'Lista'],['../classLista.html#a1f668b36909182ef1360b48503529a31',1,'Lista::Lista()'],['../classLista.html#adb33dfb3ac2cfef81f52af48afeef0a7',1,'Lista::Lista(string cadena)']]],
  ['lista_2eh',['lista.h',['../lista_8h.html',1,'']]],
  ['longitud',['longitud',['../classLista.html#a445fbaf0a89d99ed9830ae7d0c8dd12f',1,'Lista']]]
];
