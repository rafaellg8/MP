var searchData=
[
  ['celda',['Celda',['../structCelda.html',1,'']]],
  ['columnas',['columnas',['../classImagen.html#a53d3de2d3cea5aa472bdd85941a0f020',1,'Imagen']]]
];
