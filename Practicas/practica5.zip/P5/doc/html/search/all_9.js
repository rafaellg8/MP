var searchData=
[
  ['operator_3d',['operator=',['../classImagen.html#a42f9da6447dae609694ba914afe5cfa9',1,'Imagen']]]
];
