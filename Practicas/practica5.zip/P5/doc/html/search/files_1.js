var searchData=
[
  ['lista_2eh',['lista.h',['../lista_8h.html',1,'']]]
];
