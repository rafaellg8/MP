var searchData=
[
  ['escribirimagen',['escribirImagen',['../classImagen.html#aec07c487f3cb1ea1fdd26cb555f02ed1',1,'Imagen']]],
  ['escribirpgmbinario',['escribirPGMBinario',['../pgm_8h.html#a381cd69ce2e9de0b0e3b12131a397121',1,'escribirPGMBinario(const char nombre[], const unsigned char datos[], int filas, int columnas):&#160;pgm.cpp'],['../pgm_8cpp.html#a381cd69ce2e9de0b0e3b12131a397121',1,'escribirPGMBinario(const char nombre[], const unsigned char datos[], int filas, int columnas):&#160;pgm.cpp']]],
  ['escribirpgmtexto',['escribirPGMTexto',['../pgm_8h.html#a0ecaed351740580902d90a4c496a0e3b',1,'escribirPGMTexto(const char nombre[], const unsigned char datos[], int filas, int columnas):&#160;pgm.cpp'],['../pgm_8cpp.html#a0ecaed351740580902d90a4c496a0e3b',1,'escribirPGMTexto(const char nombre[], const unsigned char datos[], int filas, int columnas):&#160;pgm.cpp']]]
];
