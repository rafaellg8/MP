var searchData=
[
  ['imagen',['Imagen',['../classImagen.html#ab2e649aa7a105155c7bfdb846abf0528',1,'Imagen::Imagen()'],['../classImagen.html#a7632978f5ae089713e652bb362da1e78',1,'Imagen::Imagen(int filas, int columnas)'],['../classImagen.html#a80670a88a64f67d1bce5e790f0a47da1',1,'Imagen::Imagen(const Imagen &amp;copy)']]],
  ['imprimir',['imprimir',['../classImagen.html#aae5dca1bf7bea2ed84fe140b5a212fd2',1,'Imagen']]],
  ['infopgm',['infoPGM',['../pgm_8h.html#a85c7f15bdcdee461eba76965aaccb910',1,'infoPGM(const char nombre[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp'],['../pgm_8cpp.html#a85c7f15bdcdee461eba76965aaccb910',1,'infoPGM(const char nombre[], int &amp;filas, int &amp;columnas):&#160;pgm.cpp']]],
  ['insertar',['insertar',['../classLista.html#a2cf31ee7be6ed41e9084efffb807aa5e',1,'Lista']]]
];
