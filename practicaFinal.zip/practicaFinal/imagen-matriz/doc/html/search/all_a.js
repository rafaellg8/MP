var searchData=
[
  ['set',['set',['../classImagen.html#a722347f0110d794f96c92beda6710158',1,'Imagen']]],
  ['setpos',['setPos',['../classImagen.html#a9c1bfd9bff6ae8851f3e0c9ac2e90382',1,'Imagen']]],
  ['siguiente',['siguiente',['../structCelda.html#a5c6d6d20b0c0b0a359715844955a0078',1,'Celda']]]
];
