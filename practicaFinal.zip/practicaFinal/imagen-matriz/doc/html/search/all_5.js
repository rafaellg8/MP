var searchData=
[
  ['get',['get',['../classImagen.html#a1e5df572e1ddb6d973d430e39a7d6933',1,'Imagen']]],
  ['getcelda',['getCelda',['../classLista.html#a69c0764aa81aca4543b2a9898d941f51',1,'Lista']]],
  ['getpos',['getPos',['../classImagen.html#a41d497000e03bd5ca8d32068eac2a238',1,'Imagen::getPos(int i) const '],['../classImagen.html#a903bfa18bddaed521557d73d483b2087',1,'Imagen::getPos(int i)']]]
];
