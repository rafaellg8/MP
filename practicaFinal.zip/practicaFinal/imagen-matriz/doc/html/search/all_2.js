var searchData=
[
  ['celda',['Celda',['../structCelda.html',1,'']]],
  ['columnas',['columnas',['../classImagen.html#a934724c5328fb53ae4e8e7b8f5bea2ce',1,'Imagen']]]
];
