var searchData=
[
  ['operator_2b',['operator+',['../classLista.html#a02630588da3ea083680c73ed4434cb72',1,'Lista']]],
  ['operator_3d',['operator=',['../classImagen.html#a42f9da6447dae609694ba914afe5cfa9',1,'Imagen::operator=()'],['../classLista.html#a8e15d78e45d53ef28d3da4f17b245ebc',1,'Lista::operator=()']]]
];
