var searchData=
[
  ['aarteascii',['aArteASCII',['../classImagen.html#adbb66160513ece2f58ed6c9f9fcb9794',1,'Imagen::aArteASCII(const char grises[], char **arteASCII, int maxlong, int cardinal)'],['../classImagen.html#a0b32aeab505b6efe14e6680fa2eb067b',1,'Imagen::aArteASCII(const char grises[], char **arteASCII, int maxlong)']]]
];
