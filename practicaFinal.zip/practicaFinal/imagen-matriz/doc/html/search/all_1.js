var searchData=
[
  ['byte',['byte',['../imagen_8h.html#a0c8186d9b9b7880309c27230bbb5e69d',1,'byte():&#160;imagen.h'],['../pgm_8h.html#a0c8186d9b9b7880309c27230bbb5e69d',1,'byte():&#160;pgm.h']]]
];
