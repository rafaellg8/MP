var searchData=
[
  ['filas',['filas',['../classImagen.html#af611fc24193bfb6020115243f97aa478',1,'Imagen']]]
];
