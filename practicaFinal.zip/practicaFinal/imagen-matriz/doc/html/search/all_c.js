var searchData=
[
  ['_7eimagen',['~Imagen',['../classImagen.html#a03dd93c9cf920a9dc0b72f8bd34f2e8a',1,'Imagen']]],
  ['_7elista',['~Lista',['../classLista.html#a4d7394b2728a00ad8404965b2e15d096',1,'Lista']]]
];
