var searchData=
[
  ['escribirimagen',['escribirImagen',['../classImagen.html#a88076a01ec06391efd3437f11ec6e14c',1,'Imagen']]],
  ['escribirpgmbinario',['escribirPGMBinario',['../pgm_8h.html#aab9fb67241aaf7c907f42dfb4fdd46e4',1,'escribirPGMBinario(const char nombre[], const byte **datos, int filas, int columnas):&#160;pgm.cpp'],['../pgm_8cpp.html#aab9fb67241aaf7c907f42dfb4fdd46e4',1,'escribirPGMBinario(const char nombre[], const byte **datos, int filas, int columnas):&#160;pgm.cpp']]],
  ['escribirpgmtexto',['escribirPGMTexto',['../pgm_8h.html#ac2bca602f676c790fdcc2ff5c3436573',1,'escribirPGMTexto(const char nombre[], const byte **datos, int filas, int columnas):&#160;pgm.cpp'],['../pgm_8cpp.html#ac2bca602f676c790fdcc2ff5c3436573',1,'escribirPGMTexto(const char nombre[], const byte **datos, int filas, int columnas):&#160;pgm.cpp']]],
  ['esnula',['esNula',['../classLista.html#a8d740cc1d98a4124a068e6d1559d4f19',1,'Lista']]]
];
