var searchData=
[
  ['aarteascii',['aArteASCII',['../classImagen.html#ac161a66104681c3c8a9d2676aa4466bb',1,'Imagen::aArteASCII(const char grises[], char arteASCII[], int maxlong)'],['../classImagen.html#a377f3f01d761a92f7240394aeff6df12',1,'Imagen::aArteASCII(const char grises[], char arteASCII[], int maxlong, int tamGrises)']]]
];
